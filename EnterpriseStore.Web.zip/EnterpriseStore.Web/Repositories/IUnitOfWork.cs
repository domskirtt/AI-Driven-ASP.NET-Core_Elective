using EnterpriseStore.Web.Models;

namespace EnterpriseStore.Web.Repositories
{
    public interface IUnitOfWork : IAsyncDisposable
    {
        IRepository<Product> Products { get; }
        IRepository<Order> Orders { get; }
        IRepository<OrderItem> OrderItems { get; }

        Task<int> CompleteAsync();
    }
}
