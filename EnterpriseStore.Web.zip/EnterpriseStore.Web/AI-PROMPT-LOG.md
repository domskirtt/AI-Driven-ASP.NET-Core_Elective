# AI-Prompt Log & Audit

## Project
E-Commerce Inventory & Order Tracking Subsystem (ASP.NET Core MVC + EF Core)

## System Prompt Used for the Generic Repository Pattern

```
Generate a generic repository pattern for an ASP.NET Core 8 MVC app using EF Core.
Context: ApplicationDbContext (Data/ApplicationDbContext.cs) exposes DbSet<Product>,
DbSet<Order>, DbSet<OrderItem>. Entities live in the Models namespace.

Create:
1. IRepository<T> with async methods: GetAllAsync, GetByIdAsync(int id),
   FindAsync(Expression<Func<T,bool>> predicate), AddAsync, Update, Delete.
2. Repository<T> : IRepository<T> implementing the interface against
   ApplicationDbContext, injected via constructor, using DbSet<T>.
3. Do not call SaveChangesAsync inside the repository — that belongs to a
   separate Unit of Work layer.
4. Use nullable reference types and async/await throughout.
Target framework: net8.0. Output only the two C# files, no explanation.
```

This prompt worked cleanly on the first pass because it (a) named the exact
DbContext and entity namespaces so Copilot didn't invent placeholder types,
and (b) explicitly excluded `SaveChangesAsync` from the repository, which is
the most common reason Copilot bakes persistence logic into the wrong layer.

## AI Error Analysis

**Mistake found:** In the first iteration, Copilot's generated `Repository<T>.Update()`
method called `_context.SaveChangesAsync()` directly inside the repository. This
broke the intended architecture, since saving should be coordinated by the Unit
of Work across multiple repositories in one transaction — not fired per repository
call. It also caused a compile-time ambiguity once `UnitOfWork.CompleteAsync()`
was added, since two code paths could commit the same `DbContext` instance.

**Correction prompt deployed:**

```
Refactor Repository<T>.Update and Repository<T>.Delete so they only mutate
EF Core's change tracker (Attach / Entry().State / Remove) and never call
SaveChangesAsync. Persistence must happen exclusively through
UnitOfWork.CompleteAsync(), which wraps a single DbContext instance shared
by all repositories exposed on IUnitOfWork.
```

After this correction, `SaveChangesAsync` calls were consolidated into a single
`UnitOfWork.CompleteAsync()` method, and repositories became purely
change-tracking wrappers, restoring the intended [Controller] → [UnitOfWork] →
[Repository<T>] → [DbContext] separation of concerns.

## DI Lifetime Notes

- `ApplicationDbContext` — **Scoped** (default for `AddDbContext`), one instance per HTTP request.
- `IRepository<T>` / `Repository<T>` — **Scoped**, registered as an open generic so it shares the same `DbContext` instance as everything else in the request.
- `IUnitOfWork` / `UnitOfWork` — **Scoped**, wraps the same `DbContext` instance injected into the repositories, which is what makes `CompleteAsync()` a single atomic commit across `Products`, `Orders`, and `OrderItems`.

Singleton was deliberately avoided for any of these three, since a singleton
`DbContext` is not thread-safe and would leak state across unrelated requests.
